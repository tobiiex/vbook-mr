var BASE_URL = "https://metruyenchuvn.org";
var UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";

var LAST_ERR = "";
function errInfo() { return LAST_ERR ? " (" + LAST_ERR + ")" : ""; }

function readResp(r, url) {
    if (!r) { LAST_ERR = "không có phản hồi"; return null; }
    var st, okFlag;
    try { st = (typeof r.status === "function") ? r.status() : r.status; } catch (e) {}
    try { okFlag = (typeof r.ok === "function") ? r.ok() : r.ok; } catch (e) {}
    // Một số môi trường (tester) không trả về thuộc tính ok -> suy ra từ status, hoặc cứ thử đọc html
    if (okFlag === undefined || okFlag === null) {
        okFlag = (st === undefined || st === null) ? true : (st >= 200 && st < 400);
    }
    if (!okFlag) {
        LAST_ERR = "HTTP " + ((st === undefined || st === null) ? "?" : st) + " tại " + url;
        return null;
    }
    try {
        var d = r.html();
        if (d) return d;
        LAST_ERR = "trang trả về rỗng tại " + url;
    } catch (e2) { LAST_ERR = "lỗi đọc HTML: " + String(e2); }
    return null;
}

function tryFetch(url, opts) {
    try {
        return readResp(opts ? fetch(url, opts) : fetch(url), url);
    } catch (e) { LAST_ERR = "lỗi fetch: " + String(e); }
    return null;
}

function fetchHtml(url) {
    url = (url || "").replace(/[.\u2026\s]+$/, "");
    var doc = null;
    if (typeof fetch === "function") {
        doc = tryFetch(url, { headers: { "User-Agent": UA, "Referer": BASE_URL + "/" } });
        if (doc) return doc;
        doc = tryFetch(url, null);
        if (doc) return doc;
        if (url.indexOf("metruyenchuvn.org") !== -1) {
            doc = tryFetch(url.replace("metruyenchuvn.org", "metruyenchuvn.com"), null);
            if (doc) return doc;
        }
    }
    try {
        if (typeof Http !== "undefined") {
            doc = readResp(Http.get(url), url);
            if (doc) return doc;
        }
    } catch (e3) { LAST_ERR = "lỗi Http: " + String(e3); }
    return null;
}

function absUrl(u) {
    u = (u || "").trim();
    if (!u) return "";
    if (u.indexOf("//") === 0) return "https:" + u;
    if (u.indexOf("http") === 0) return u;
    return BASE_URL + "/" + u.replace(/^\//, "");
}

function count(els) {
    if (!els) return 0;
    try { return els.size(); } catch (e) {}
    return els.length || 0;
}

function withPage(url, page) {
    url = url.replace(/\/+$/, "");
    if (!page || String(page) === "1") return url;
    return url + (url.indexOf("?") === -1 ? "?" : "&") + "page=" + page;
}

function hasNextPage(doc, page) {
    var n = parseInt(page, 10) + 1;
    return count(doc.select("a[href*='page=" + n + "']")) > 0;
}

function isNovelLink(href) {
    if (!href || href.indexOf("javascript") !== -1 || href.indexOf("#") !== -1) return false;
    return !/\/(danh-sach|the-loai|tim-kiem|tac-gia|contact|tos)(\/|\?|$)/.test(href) && href.indexOf("/chuong-") === -1;
}

function tagOf(el) {
    try { return (el.tagName() || "").toLowerCase(); } catch (e) { return ""; }
}

function sib(el, dir) {
    try { return dir < 0 ? el.previousElementSibling() : el.nextElementSibling(); } catch (e) { return null; }
}

// Tìm khối bao quanh 1 truyện: đi từ thẻ h3 lên cho tới khi khối chứa nhiều hơn 1 truyện
function findBox(h3) {
    var box = h3;
    var best = null;
    for (var i = 0; i < 6; i++) {
        var p = null;
        try { p = box.parent(); } catch (e) {}
        if (!p) break;
        if (count(p.select("h3 a[href]")) > 1) break;
        box = p;
        if (count(box.select("img")) > 0) best = box;
    }
    return best;
}

function pickCover(box) {
    var cover = "";
    box.select("img").forEach(function (img) {
        var src = absUrl(img.attr("data-src") || img.attr("data-original") || img.attr("data-lazy-src") || img.attr("src") || "");
        if (!src || src.indexOf("data:") !== -1) return;
        if (src.indexOf("/media/book/") !== -1) { if (cover.indexOf("/media/book/") === -1) cover = src; }
        else if (!cover) cover = src;
    });
    return cover;
}

// Trường hợp các phần tử của 1 truyện nằm "phẳng" cạnh nhau (không có khối bao): quét anh em quanh thẻ h3
function siblingScopes(h3) {
    var before = [];
    var after = [];
    var el = sib(h3, -1);
    var n = 0;
    while (el && n < 3 && tagOf(el) !== "h3") {
        before.push(el);
        if (count(el.select("img")) > 0 || tagOf(el) === "img") break;
        el = sib(el, -1);
        n++;
    }
    el = sib(h3, 1);
    n = 0;
    while (el && n < 10 && tagOf(el) !== "h3") {
        if (count(el.select("img")) > 0 || tagOf(el) === "img") break;
        after.push(el);
        el = sib(el, 1);
        n++;
    }
    return { before: before, after: after };
}

function ck(u) { return (u || "").replace(/[?#].*$/, "").replace(/\/+$/, ""); }

// Ghép ảnh bìa theo link: ảnh nằm trong thẻ <a href=link> thì là bìa của truyện có link đó,
// không phụ thuộc ảnh và tiêu đề nằm ở đâu trong cấu trúc HTML.
function buildCoverMap(doc) {
    var map = {};
    doc.select("img").forEach(function (img) {
        var src = absUrl(img.attr("data-src") || img.attr("data-original") || img.attr("data-lazy-src") || img.attr("src") || "");
        if (!src || src.indexOf("data:") !== -1) return;
        var el = img;
        for (var i = 0; i < 4; i++) {
            try { el = el.parent(); } catch (e) { el = null; }
            if (!el) break;
            if (tagOf(el) === "a") {
                var key = ck(absUrl(el.attr("href")));
                if (key && (!map[key] || (src.indexOf("/media/book/") !== -1 && map[key].indexOf("/media/book/") === -1))) map[key] = src;
                break;
            }
        }
    });
    return map;
}

function parseList(doc) {
    var data = [];
    var seen = {};
    var covers = buildCoverMap(doc);

    // Trang chủ: mục slide có cấu trúc  #slide .item > a[href][title] > img + .caption
    doc.select("#slide .item a[href], .slide .item a[href]").forEach(function (a) {
        if (count(a.select("img")) === 0) return;
        var link = absUrl(a.attr("href"));
        if (!isNovelLink(link) || seen[link]) return;
        var capEl = a.select(".caption h3, .caption h2, .caption .title, h3").first();
        var name = capEl ? (capEl.text() || "").trim() : "";
        if (!name) name = (a.attr("title") || "").replace(/\s*đọc online\s*$/i, "").trim();
        if (!name) return;
        seen[link] = true;
        data.push({ name: name, link: link, cover: pickCover(a) || covers[ck(link)] || "", description: "", host: BASE_URL });
    });

    doc.select("h3 a[href]").forEach(function (a) {
        var link = absUrl(a.attr("href"));
        if (!isNovelLink(link) || seen[link]) return;
        var name = (a.text() || "").trim();
        if (!name) return;

        var h3 = null;
        try { h3 = a.parent(); } catch (e) {}

        var cover = "";
        var scopes = [];
        var box = h3 ? findBox(h3) : null;
        if (box) {
            cover = pickCover(box);
            scopes.push(box);
        } else if (h3) {
            var ss = siblingScopes(h3);
            ss.before.forEach(function (e) { if (!cover) cover = pickCover(e); });
            scopes = ss.after;
        }

        var author = "";
        var genres = [];
        var chap = "";
        scopes.forEach(function (sc) {
            if (!author) {
                var authorA = sc.select("a[href*='/tac-gia/']").first();
                if (authorA) author = (authorA.text() || "").trim();
            }
            sc.select("a[href*='/the-loai/']").forEach(function (g) {
                var t = (g.text() || "").trim();
                if (t && genres.indexOf(t) === -1) genres.push(t);
            });
            if (!chap) {
                var m = /Số chương\s*:\s*([\d.,]+)/.exec(sc.text() || "");
                if (m) chap = m[1];
            }
        });

        var parts = [];
        if (author) parts.push("Tác giả: " + author);
        if (genres.length) parts.push("Thể loại: " + genres.join(", "));
        if (chap) parts.push(chap + " chương");

        if (!cover) cover = covers[ck(link)] || "";
        seen[link] = true;
        data.push({
            name: name,
            link: link,
            cover: cover,
            description: parts.join(" · "),
            host: BASE_URL
        });
    });

    // Dự phòng: link có ảnh bìa + thuộc tính title
    if (data.length === 0) {
        doc.select("a[href][title]").forEach(function (a) {
            if (count(a.select("img")) === 0) return;
            var link = absUrl(a.attr("href"));
            if (!isNovelLink(link) || seen[link]) return;
            var name = (a.attr("title") || "").replace(/\s*đọc online\s*$/i, "").trim();
            if (!name) return;
            seen[link] = true;
            data.push({ name: name, link: link, cover: pickCover(a), description: "", host: BASE_URL });
        });
    }
    return data;
}

function normalize(s) {
    return (s || "").toLowerCase()
        .replace(/đ/g, "d")
        .normalize("NFD").replace(/[\u0300-\u036f]/g, "")
        .replace(/[^a-z0-9]+/g, " ").trim();
}

function matchScore(data, keyword) {
    var tokens = normalize(keyword).split(" ").filter(function (t) { return t; });
    if (tokens.length === 0) return 0;
    var score = 0;
    data.forEach(function (it) {
        var hay = normalize(it.name) + " " + normalize(it.link.replace(BASE_URL, ""));
        for (var i = 0; i < tokens.length; i++) {
            if (hay.indexOf(tokens[i]) !== -1) { score++; break; }
        }
    });
    return score;
}

function execute(key, page) {
    if (!page) page = "1";
    var keyword = (typeof key === "string") ? key.trim() : "";
    if (!keyword) return Response.success([], null);

    var q = encodeURIComponent(keyword);
    var pg = (String(page) === "1") ? "" : "&page=" + page;
    // Chưa xác định được địa chỉ tìm kiếm chính xác của web nên thử lần lượt các dạng phổ biến
    var candidates = [
        BASE_URL + "/tim-kiem?keyword=" + q + pg,
        BASE_URL + "/tim-kiem?q=" + q + pg,
        BASE_URL + "/tim-kiem?tukhoa=" + q + pg,
        BASE_URL + "/search?keyword=" + q + pg,
        BASE_URL + "/search?q=" + q + pg,
        BASE_URL + "/?s=" + q + pg
    ];

    for (var i = 0; i < candidates.length; i++) {
        var doc = fetchHtml(candidates[i]);
        if (!doc) continue;
        var data = parseList(doc);
        // Chỉ nhận kết quả thật sự liên quan tới từ khoá (tránh trường hợp web bỏ qua tham số và trả về trang chủ)
        if (data.length > 0 && matchScore(data, keyword) > 0) {
            var next = hasNextPage(doc, page) ? String(parseInt(page, 10) + 1) : null;
            return Response.success(data, next);
        }
    }
    return Response.success([], null);
}
